Place 'meshsurface.ms' in your #startupScripts folder. (C:\Program Files\Autodesk\3ds Max\<Version>\scripts\startup)

After initializing Orion.mzp. You'll find the script available under the Category: Orion Scripts.