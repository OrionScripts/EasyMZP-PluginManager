Place your TopoLogiK_1.lic file in the root of your #scripts directory. You'll have received this directly from Kinematic Labs/Hocus Pocus.

Place all files in this directory in a folder called 'TopoLogiK' located in your #scripts directory. (C:\Program Files\Autodesk\3ds Max\<Version>\scripts\)

You'll find the scripts available under the Category: Orion Scripts in the 'Customize UI' menu.