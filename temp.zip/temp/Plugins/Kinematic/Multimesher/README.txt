Place 'Multimesher_v02.mse' in your #startupScripts folder. (C:\Program Files\Autodesk\3ds Max\<Version>\scripts\startup)

You'll find the script available under the Category: Kinematic Lab in the 'Create' menu.