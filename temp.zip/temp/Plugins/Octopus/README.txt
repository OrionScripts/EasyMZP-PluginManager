Place Octopus.dll in C:\Program Files\Autodesk\<Version>\bin\assemblies.

Place OctopusCLI.gup in C:\Program Files\Autodesk\<Version>\Plugins.