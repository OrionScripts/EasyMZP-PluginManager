To install:
	1. Copy DANDG_Collapse.ms to your maxroot/scripts directory. 
	2. Run the macro. 
	3. You can now add it to a menu etc. 