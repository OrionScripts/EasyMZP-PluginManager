Copy arrow.ms to C:\Program Files\Autodesk\3ds Max 2020\scripts\Startup

Spline will show up under 'Arrows' category in Create panel.